-- SUMMARY --

Breakpoints

Multipliers
-----------

For the moment hard-coded: variable_get('breakpoints_multipliers', array('1x', '1.5x', '2x'));