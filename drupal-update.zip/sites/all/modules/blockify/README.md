#Blockify

This module exposes a number of core Drupal elements as blocks.

##Supported elements:

* Logo
* Site name
* Site slogan
* Page title
* Breadcrumb
* Tabs
* Messages
* Local actions
* Feed icons

The module provides an administrations settings page to enable/disable blockify blocks installation-wide.

##Authors, maintainers, and general kudos

* [Bantalabs](http://bantalabs.com)
* [mortendk](http://drupal.org/user/65676)
* [psynaptic](http://drupal.org/user/93429)
